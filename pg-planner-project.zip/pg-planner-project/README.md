# Brampton → Prince George · Journey Planner

A single-page interactive planner for a cross-country family move from Brampton, ON to Prince George, BC (July 25 – July 31, 2026). Pre-departure checklists, a verified 7-day road trip itinerary via the Yellowhead Highway, Prince George setup tasks, and a built-in expense tracker with sale-credit accounting.

Built as plain HTML + CSS + vanilla JS — no build step, no dependencies. Open `index.html` in a browser and it works.

## Project structure

```
pg-planner-project/
├── index.html          # Markup: header, tabs, all 5 sections
├── css/
│   └── styles.css      # All styling (CSS variables, layout, components)
├── js/
│   └── app.js          # Tab routing, localStorage persistence, expense logic
├── .gitignore
├── serve.sh            # Convenience script: python3 -m http.server 8000
└── README.md           # This file
```

## Running locally

### Option A — open the file directly
Double-click `index.html`. It works from `file://` URLs.

### Option B — local server (recommended for development)
```bash
./serve.sh
# or
python3 -m http.server 8000
```
Then open http://localhost:8000.

> **Note:** `file://` and `http://localhost` are different origins for `localStorage`, so progress saved by opening the file directly won't appear when you serve it. Pick one method and stick with it.

## Tech stack

| Layer | Choice | Why |
|---|---|---|
| Markup | HTML5, semantic | No framework needed for a static planner |
| Styling | Vanilla CSS, CSS variables | Theming via `:root` vars, no preprocessor |
| Typography | Fraunces (display), Outfit (body), JetBrains Mono (meta) | Loaded from Google Fonts CDN |
| Behaviour | Vanilla JS (ES2017+) | No framework, no transpile |
| Storage | `window.localStorage` | Per-browser persistence, no backend |

## Data model

All state lives in two `localStorage` keys:

| Key | Contents |
|---|---|
| `pg-journey-planner-v1` | Map of checkbox keys → booleans + sale-price keys → numeric strings |
| `pg-journey-expenses-v1` | Array of `{date, desc, cat, phase, amount}` objects |

Inspect via DevTools → Application tab → Local Storage.

## Sections (tabs)

1. **Dashboard** — Live progress bars, recommended timeline, documents-to-carry box.
2. **Brampton Tasks** — 9 numbered subsections covering insurance, utilities, banks (CIBC, Wealthsimple), 6 credit cards, address updates, Ontario documents, family/health/school, vehicle prep, items to sell with "Sold for $" inputs.
3. **Road Trip Plan** — 7 day cards with route timings, hotel options, verified Indian restaurants, Akshara-friendly stops, time-zone warnings, and Jasper post-wildfire booking advice.
4. **Prince George Setup** — Service BC, ICBC, MSP, utilities, school district, things-to-buy grid.
5. **Expense Tracker** — Add/delete entries by date/category/phase, summary cards (Total spent / Sale credits / Net cost), CSV export.

## Customizing

### Change a default value
Edit the relevant `<label class="check-item">` block in `index.html`. Each checkbox has a stable `data-key` attribute — keep this if you want previously-checked progress to carry over.

### Change theme colours
All colours are CSS variables defined in `css/styles.css` under `:root`. Swap the values to retheme:

```css
:root {
  --paper: #f5efe4;        /* page background */
  --ink: #1c2920;          /* body text */
  --moss: #2d4a33;         /* primary accent */
  --amber: #c8731e;        /* secondary accent */
  --terracotta: #a64428;   /* tertiary / warnings */
  /* ... */
}
```

### Add a new sell-item
1. In `index.html`, find the `.sell-grid` and add a new `<label class="sell-item">` block following the pattern.
2. Give it unique `data-key` (e.g. `sell-microwave`) and matching `data-price` (`sell-microwave-price`).
3. No JS change needed — the totals function picks up any element with `.sell-price[data-price]`.

### Add an expense category
In `index.html`, find `<select id="exp-cat">` and add a new `<option>`. That's it.

## Browser support

Tested in Chrome, Firefox, Edge (current versions). Uses:
- CSS custom properties (universal)
- `grid-template-columns: repeat(auto-fit, minmax(...))` (universal)
- `localStorage` API (universal)
- `<input type="number">` with no spinner styling (works everywhere; spinner hidden via vendor prefixes)
- No ES6 modules — single `app.js` is a regular script

Mobile-responsive via media queries at 720px and 900px breakpoints.

## Print

Press `Ctrl/Cmd + P` or click the "🖨 Print this planner" button. Tabs, buttons, and form inputs are hidden in print CSS; all tab content is expanded so the whole planner prints as one document.

## Data export

The **⤓ Export CSV** button in the Expense Tracker dumps all expenses + sale-credits + totals as a CSV file named `expenses-bp-to-pg-YYYY-MM-DD.csv`. Open in Excel, Google Sheets, or Numbers.

## Caveats

- **No cloud sync.** Data is per-browser. To back up: use the CSV export, or copy localStorage contents from DevTools.
- **No multi-device sync.** Different devices = different ledgers.
- **No undo.** Deleting an expense or clicking "Reset progress" is permanent. Reset is confirmation-gated.

## License

Personal use. Adapt freely for your own moves.
