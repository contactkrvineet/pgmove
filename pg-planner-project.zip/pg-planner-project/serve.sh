#!/usr/bin/env bash
# Serve the planner locally on http://localhost:8000
# Usage: ./serve.sh [port]

PORT="${1:-8000}"

echo "→ Serving on http://localhost:$PORT (Ctrl+C to stop)"

if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server "$PORT"
elif command -v python >/dev/null 2>&1; then
  python -m SimpleHTTPServer "$PORT"
else
  echo "✗ Python not found. Install Python 3 or open index.html directly."
  exit 1
fi
