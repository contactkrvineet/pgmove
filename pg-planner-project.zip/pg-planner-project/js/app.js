/* ==========================================================================
   Brampton → Prince George · Journey Planner
   Application logic
   --------------------------------------------------------------------------
   No build step. ES2017+ vanilla JS, runs from a single <script> tag.
   --------------------------------------------------------------------------
   Modules (top-to-bottom):
     1. Storage helpers (load/save state + expenses to localStorage)
     2. Tab routing
     3. Checkbox persistence + sell-item "sold" class toggling
     4. Sell-price inputs (save, sum, sync to dashboard + expense summary)
     5. Dashboard stat counters & progress bars
     6. Expense tracker: render, add, delete, CSV export, clear, reset
   --------------------------------------------------------------------------
   Storage keys:
     pg-journey-planner-v1   { [data-key]: boolean | [data-price]: string }
     pg-journey-expenses-v1  Array<{ date, desc, cat, phase, amount }>
   ========================================================================== */

  // ===== STORAGE HELPERS =====
  const STORAGE_KEY = 'pg-journey-planner-v1';
  const EXP_KEY = 'pg-journey-expenses-v1';

  function loadState() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
    catch { return {}; }
  }
  function saveState(state) { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  function loadExpenses() {
    try { return JSON.parse(localStorage.getItem(EXP_KEY) || '[]'); }
    catch { return []; }
  }
  function saveExpenses(arr) { localStorage.setItem(EXP_KEY, JSON.stringify(arr)); }

  // ===== TABS =====
  document.querySelectorAll('.tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });

  // ===== CHECKBOXES =====
  const state = loadState();
  document.querySelectorAll('input[type="checkbox"][data-key]').forEach(cb => {
    if (state[cb.dataset.key]) cb.checked = true;
    cb.addEventListener('change', () => {
      state[cb.dataset.key] = cb.checked;
      saveState(state);
      updateDashboard();
      // toggle .sold class on parent sell-item
      const sellItem = cb.closest('.sell-item');
      if (sellItem) sellItem.classList.toggle('sold', cb.checked);
    });
    // initial sold class
    const sellItem = cb.closest('.sell-item');
    if (sellItem && cb.checked) sellItem.classList.add('sold');
  });

  // ===== SELL-PRICE INPUTS =====
  // Prevent the price field click from toggling the parent label's checkbox
  document.querySelectorAll('.price-wrap, .sell-price').forEach(el => {
    el.addEventListener('click', e => e.preventDefault());
    el.addEventListener('mousedown', e => e.stopPropagation());
  });
  // But still allow focus + typing
  document.querySelectorAll('.sell-price').forEach(inp => {
    inp.addEventListener('click', e => { e.stopPropagation(); inp.focus(); });
  });

  function getSellTotal() {
    let total = 0;
    document.querySelectorAll('.sell-price[data-price]').forEach(inp => {
      const v = parseFloat(state[inp.dataset.price]);
      if (!isNaN(v)) total += v;
    });
    return total;
  }
  function updateSellTotal() {
    const el = document.getElementById('sell-total');
    if (el) el.textContent = '$' + getSellTotal().toFixed(2);
  }
  document.querySelectorAll('.sell-price[data-price]').forEach(inp => {
    const saved = state[inp.dataset.price];
    if (saved !== undefined && saved !== null && saved !== '') inp.value = saved;
    inp.addEventListener('input', () => {
      state[inp.dataset.price] = inp.value;
      saveState(state);
      updateSellTotal();
      renderExpenses(); // refresh the summary in the expense tracker
    });
  });
  updateSellTotal();

  // ===== DASHBOARD STATS =====
  function updateDashboard() {
    const bramptonBoxes = document.querySelectorAll('#brampton input[type="checkbox"][data-key]:not([data-key^="sell-"])');
    const sellBoxes = document.querySelectorAll('#brampton input[type="checkbox"][data-key^="sell-"]');
    const roadBoxes = document.querySelectorAll('#roadtrip input[type="checkbox"][data-key$="-done"]');
    const pgBoxes = document.querySelectorAll('#prince-george input[type="checkbox"][data-key]');

    function pct(checked, total) { return total ? Math.round(checked / total * 100) : 0; }
    function count(nodeList) {
      let c = 0; nodeList.forEach(n => { if (n.checked) c++; });
      return c;
    }

    const bC = count(bramptonBoxes), bT = bramptonBoxes.length;
    const sC = count(sellBoxes), sT = sellBoxes.length;
    const rC = count(roadBoxes), rT = roadBoxes.length;
    const pC = count(pgBoxes), pT = pgBoxes.length;

    document.getElementById('stat-brampton').textContent = `${bC}/${bT}`;
    document.getElementById('stat-brampton-pct').textContent = `${pct(bC, bT)}% complete`;
    document.getElementById('bar-brampton').style.width = pct(bC, bT) + '%';

    document.getElementById('stat-sell').textContent = `${sC}/${sT}`;
    const sellDetailEl = document.getElementById('stat-sell-detail');
    if (sellDetailEl) sellDetailEl.textContent = '$' + getSellTotal().toFixed(2) + ' earned';
    document.getElementById('bar-sell').style.width = pct(sC, sT) + '%';

    document.getElementById('stat-road').textContent = `${rC}/${rT}`;
    document.getElementById('bar-road').style.width = pct(rC, rT) + '%';

    document.getElementById('stat-pg').textContent = `${pC}/${pT}`;
    document.getElementById('stat-pg-pct').textContent = `${pct(pC, pT)}% complete`;
    document.getElementById('bar-pg').style.width = pct(pC, pT) + '%';
  }
  updateDashboard();

  // ===== EXPENSES =====
  let expenses = loadExpenses();

  document.getElementById('exp-date').valueAsDate = new Date();

  function renderExpenses() {
    const tbody = document.getElementById('exp-tbody');
    const summary = document.getElementById('exp-summary');
    const credit = getSellTotal();
    if (expenses.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No expenses logged yet. Add your first above ↑</td></tr>';
      summary.innerHTML =
        `<div class="summary-card total"><div class="label">Total spent</div><div class="amount">$0.00</div></div>` +
        `<div class="summary-card credit"><div class="label">Sale credits</div><div class="amount">$${credit.toFixed(2)}</div></div>` +
        `<div class="summary-card net"><div class="label">Net cost</div><div class="amount">$${(-credit).toFixed(2)}</div></div>`;
      return;
    }

    // table
    tbody.innerHTML = expenses.slice().reverse().map((e, i) => `
      <tr>
        <td>${e.date}</td>
        <td>${escapeHtml(e.desc)}</td>
        <td><span class="cat-tag">${e.cat}</span></td>
        <td>${e.phase}</td>
        <td class="amount-col">$${e.amount.toFixed(2)}</td>
        <td><button class="btn danger" data-del="${expenses.length - 1 - i}">✕</button></td>
      </tr>
    `).join('');

    // summary by category
    const total = expenses.reduce((s, e) => s + e.amount, 0);
    const net = total - credit;
    const byCat = {};
    expenses.forEach(e => { byCat[e.cat] = (byCat[e.cat] || 0) + e.amount; });
    const topCats = Object.entries(byCat).sort((a, b) => b[1] - a[1]).slice(0, 4);

    summary.innerHTML =
      `<div class="summary-card total"><div class="label">Total spent</div><div class="amount">$${total.toFixed(2)}</div></div>` +
      `<div class="summary-card credit"><div class="label">Sale credits</div><div class="amount">$${credit.toFixed(2)}</div></div>` +
      `<div class="summary-card net"><div class="label">Net cost</div><div class="amount">$${net.toFixed(2)}</div></div>` +
      topCats.map(([cat, amt]) =>
        `<div class="summary-card"><div class="label">${cat}</div><div class="amount">$${amt.toFixed(2)}</div></div>`
      ).join('');

    // delete handlers
    document.querySelectorAll('[data-del]').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.del);
        expenses.splice(idx, 1);
        saveExpenses(expenses);
        renderExpenses();
      });
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  document.getElementById('add-exp').addEventListener('click', () => {
    const date = document.getElementById('exp-date').value;
    const desc = document.getElementById('exp-desc').value.trim();
    const cat = document.getElementById('exp-cat').value;
    const phase = document.getElementById('exp-phase').value;
    const amount = parseFloat(document.getElementById('exp-amount').value);

    if (!date || !desc || isNaN(amount) || amount <= 0) {
      alert('Please fill in date, description, and a valid amount.');
      return;
    }
    expenses.push({ date, desc, cat, phase, amount });
    saveExpenses(expenses);
    renderExpenses();
    // reset
    document.getElementById('exp-desc').value = '';
    document.getElementById('exp-amount').value = '';
    document.getElementById('exp-desc').focus();
  });

  document.getElementById('export-csv').addEventListener('click', () => {
    const credit = getSellTotal();
    if (expenses.length === 0 && credit === 0) { alert('No expenses or sale credits to export.'); return; }
    const rows = [['Date', 'Description', 'Category', 'Phase', 'Amount (CAD)']]
      .concat(expenses.map(e => [e.date, e.desc, e.cat, e.phase, e.amount.toFixed(2)]));
    // append sale credits rows
    document.querySelectorAll('.sell-price[data-price]').forEach(inp => {
      const v = parseFloat(inp.value);
      if (!isNaN(v) && v > 0) {
        const item = inp.closest('.sell-item').querySelector('.item-name').textContent.trim();
        rows.push(['', 'SALE: ' + item, 'Sale Credit', 'Brampton', '-' + v.toFixed(2)]);
      }
    });
    const total = expenses.reduce((s, e) => s + e.amount, 0);
    rows.push([]);
    rows.push(['', 'Total expenses', '', '', total.toFixed(2)]);
    rows.push(['', 'Total sale credits', '', '', '-' + credit.toFixed(2)]);
    rows.push(['', 'Net cost', '', '', (total - credit).toFixed(2)]);

    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `expenses-bp-to-pg-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  });

  document.getElementById('clear-exp').addEventListener('click', () => {
    if (confirm('Delete ALL expenses? This cannot be undone.')) {
      expenses = [];
      saveExpenses(expenses);
      renderExpenses();
    }
  });

  document.getElementById('reset-all').addEventListener('click', () => {
    if (confirm('Reset ALL checklist progress? Expenses will be kept. This cannot be undone.')) {
      localStorage.removeItem(STORAGE_KEY);
      location.reload();
    }
  });

  renderExpenses();